﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OptionsPro.Models
{
    public class Shared
    {
        public string Value { get; set; }
    }
}
