﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OptionsPro.Models
{
    public class Locations
    {
        public List<string> location { get; set; }
        public string Name { get; set; }
    }
}
